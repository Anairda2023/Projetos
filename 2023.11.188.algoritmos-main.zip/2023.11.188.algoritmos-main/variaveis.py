numero1 = int(input("Digite o número 1: "))
numero2 = int(input("Digite o número 2: "))

soma             = numero1 + numero2
subtracao        = numero1 - numero2
multiplicacao    = numero1 * numero2
divisao          = numero1 / numero2
divisao_inteira  = numero1 // numero2
resto_da_divisao = numero1 % numero2

print(f"A soma de {numero1} com {numero2} é {soma}")
print(f"A subtração de {numero1} com {numero2} é {subtracao}")
print(f"A multiplicação de {numero1} com {numero2} é {multiplicacao}")
print(f"A divisão de {numero1} por {numero2} é {divisao}")
print(f"A divisão inteira de {numero1} por {numero2} é {divisao_inteira}")
print(f"O resto da divisão de {numero1} por {numero2} é {resto_da_divisao}")
