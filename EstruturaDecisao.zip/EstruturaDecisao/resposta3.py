x = input("Digite a letra M para Masculino ou a letra F para Feminino: ")
if x == "M":
    print("M - Masculino")
elif x == "F":
    print("F - Feminino")
else:
    print("Sexo inválido")