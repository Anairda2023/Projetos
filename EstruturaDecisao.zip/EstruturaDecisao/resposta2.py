x = float(input("Digite um número: "))
if x > 0:
    print("O número digitado é positivo")
elif x < 0:
    print("O número digitado é negativo")
else:
    print("O número digitado é neutro. Não é positivo nem negativo")
        