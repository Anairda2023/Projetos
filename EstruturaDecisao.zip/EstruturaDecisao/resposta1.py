x = float(input("Digite o primeiro número: "))
y = float(input("Digite o segundo número: "))
resultado = x >= y
if resultado:
  print (f"O maior entre os dois números digitados é: {x}")
else:
  print (f"O maior entre os dois números digitados é: {y}")
  