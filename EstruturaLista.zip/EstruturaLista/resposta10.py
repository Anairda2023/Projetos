x = []
print("Digite os elementos do primeiro vetor:")
for n in range(2):
    numero = int(input(f"Digite o número {n+1}: "))
    x.append(numero)
y = []
print("Digite os elementos do segundo vetor:")
for n in range(2):
    numero = int(input(f"Digite o número {n+1}: "))
    y.append(numero)

z = []
for i in range(2):
    z.append(x[i])
    z.append(y[i])

print("O Terceiro vetor intercalado é:")
print(z)

