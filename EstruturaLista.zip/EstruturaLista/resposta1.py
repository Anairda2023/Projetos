x = []

for n in range(5):
    numero = int(input(f"Digite o número {n+1}: "))
    x.append(numero)
print("Números no vetor:")
#a função map(str, vetor) é usada para converter cada número no vetor para uma string, e em seguida, o método join() é aplicado para unir essas strings em uma única string, separando-as por um espaço
numeros_na_horizontal = ' '.join(map(str, x))
print(numeros_na_horizontal) 


