x = []
for n in range(10):
    numero = int(input(f"Digite o número {n+1}: "))
    x.append(numero)
soma_quadrados = sum([numero ** 2 for numero in x])


print(f"Soma dos quadrados dos elementos do vetor A é: {soma_quadrados}")