x = []
y = []
for n in range(5):
    idade = int(input(f"Digite a sua idade {n+1}: "))
    x.append(idade)
    altura = float(input(f"Digite a sua altura em centímetros {n+1}: "))
    y.append(altura)

print("Idades na ordem inversa:")
for idade in reversed(x):
    print(idade)

print("\nAlturas na ordem inversa:")
for altura in reversed(y):
    print(altura)