x = []

for n in range(5):
    numero = int(input(f"Digite o número {n+1}: "))
    x.append(numero)

soma = sum(x)
multiplicacao = 1
for numero in x:
    multiplicacao *= numero
numeros_na_horizontal = ' '.join(map(str, x))

print(f"A soma dos números é: {soma}")
print(f"A multiplicação dos múmeros é: {multiplicacao}")
print(f"Os números são: {numeros_na_horizontal}")
