#"definir as consoantes"
def eh_consoante(caracteres):
    consoantes = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ'
#Return é usado para enviar um valor específico de volta de uma função para quem a chamou, permitindo que esse valor seja utilizado ou manipulado fora da função.
    return caracteres in consoantes
x = []

for c in range(10):
    caracteres = input(f"Digite um caractere {c+1}: ")
    x.append(caracteres)

consoantes = []
for caracteres in x:
    if eh_consoante(caracteres):
        consoantes.append(caracteres)

print("Consoantes lidas:")
for consoante in consoantes:
    print(consoante)
#O len conta o número de caracteres
quantidade_consoantes = len(consoantes)
print(f"Quantidade de consoantes lidas: {quantidade_consoantes}")        

