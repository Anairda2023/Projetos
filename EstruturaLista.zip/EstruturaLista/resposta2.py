x = []

for n in range(10):
    numero = float(input(f"Digite o número {n+1}: "))
    x.append(numero)
print("Os números digitados na ordem inversa é:")

numeros_na_ordem_inversa = reversed(x)
numeros_na_horizontal = ' '.join(map(str, numeros_na_ordem_inversa))

print(numeros_na_horizontal) 