x = []
for n in range(20):
    numeros = int(input(f"Digite um caractere {n+1}: "))
    x.append(numeros)

x_par = []
for numeros in x:
    if numeros % 2 == 0:
        x_par.append(numeros)

print("Os números pares são: ")
print(x_par)

x_impar = []
for numeros in x:
    if numeros % 2 != 0:
        x_impar.append(numeros)
print("Os números ímpares são: ")
print(x_impar)

