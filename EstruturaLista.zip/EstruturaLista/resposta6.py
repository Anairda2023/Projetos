# Função para calcular a média de um aluno
def calcular_media(notas):
    return sum(notas) / len(notas)

# Vetor para armazenar as médias dos alunos
medias_alunos = []

# Contador para alunos com média maior ou igual a 7.0
contador = 0

# Loop para ler as notas e calcular médias para 10 alunos
for i in range(10):
    print(f"Notas do aluno {i+1}:")
    notas = []
    for j in range(4):
        nota = float(input(f"Digite a nota {j+1}: "))
        notas.append(nota)
    
    media = calcular_media(notas)
    medias_alunos.append(media)
    print(f"Média do aluno {i+1}: {media:.2f}\n")
    
    if media >= 7.0:
        contador += 1

# Exibindo o número de alunos com média maior ou igual a 7.0
print(f"Número de alunos com média maior ou igual a 7.0: {contador}")