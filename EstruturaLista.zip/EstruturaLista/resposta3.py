x = []

for n in range(4):
    notas = int(input(f"Digite a nota {n+1}: "))
#Este append você vai acrescentando as notas
    x.append(notas)
# O len é o número de elementos do vetor. O range que você escolheu
media = sum(x) / len(x)
print("As notas foram:")
#Este enumerate você vai enumerando as notas
for n, notas in enumerate(x, start=1):
    print(f"Nota {n}: {notas}")
#Média formatada com duas casas decimais
print(f"Média: {media:.2f}")