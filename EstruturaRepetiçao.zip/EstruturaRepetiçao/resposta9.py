for x in range(1, 50, 2):
    print(x)