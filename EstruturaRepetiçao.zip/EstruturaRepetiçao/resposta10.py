
inicio = int(input("Digite o número do início do intervalo: "))
fim = int(input("Digite o número do final do intervalo: "))
for x in range(inicio , fim+1):
    print(f"Os números do intervalo são: {x}")  