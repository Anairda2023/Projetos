x = int(input("Insira o raio do círculo: "))
pi = 3.14159
area = pi * (x ** 2)
print("A área do cículo é: " , area)