x = int(input("Digite o comprimento: "))
y = int(input("Digite a largura: "))
area = x * y
print("O resultado do dobro da área é: ", area * 2)

