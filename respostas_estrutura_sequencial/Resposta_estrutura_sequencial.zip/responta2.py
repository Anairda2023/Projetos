x = int(input("Insira um número:"))
print("O número formado foi: " , x)
