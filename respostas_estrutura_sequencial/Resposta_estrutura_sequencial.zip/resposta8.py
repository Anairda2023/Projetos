x = int(input("Digite quanto você ganha por hora: "))
y = int(input (f"Digite quantas horas você trabalha por mês: "))
resultado = x * y
print(f"O seu salário no mês é: R$ {resultado} reais" )
