print("Alô mundo")
