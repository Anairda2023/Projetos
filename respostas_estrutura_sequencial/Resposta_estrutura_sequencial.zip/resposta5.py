x= int(input("Insira um número: "))
transformacao = x * 100
print(f"A resposta será: {transformacao} cm")
