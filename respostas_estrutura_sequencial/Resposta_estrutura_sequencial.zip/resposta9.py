x = int(input("Digite a temperatura em Fahrenheit: "))
y = 5 * ((x-32) / 9)
print (f"A temperatura em graus celsius é: {y} C")
