x =int(input("Digite a temperatura em Celsius:"))
y = 32 + 1.8 * x
print(f"A temperatura em Fahrenheit é: {y} F")