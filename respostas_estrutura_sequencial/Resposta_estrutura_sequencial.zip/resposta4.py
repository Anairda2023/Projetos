x = int(input("Insira a nota do primeiro bimestre: "))
y = int(input("Insira a nota do segundo bimestre: "))
z = int(input("Insira a nota do segundo bimestre: "))
w = int(input("Insira a nota do segundo bimestre: "))
media = (x + y + z+ w) / 4
print (" O resultado foi: " , media)
