
x = int(input("Digite o número 1: "))
y = int(input("Digite o número 2: "))
soma = x + y
print(" A soma deste dois números é: " , soma )
1